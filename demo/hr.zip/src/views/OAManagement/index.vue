<template>
  <div class="container">

    <div class="item_index1">
      <div class="item_block">
        <img src="./../../../static/img/icon/5.png" />
        <span style="color:black;font-size:20px">数据实时统计</span>
      </div>
      <div class="item_title">
        <div class="item_all">
          <div class="item_all_img">
            <img src="./../../../static/img/icon/4.png" alt />
          </div>
          <div class="item_all_qty">
            <div class="item_all_qty_word">总人数</div>
            <span>
              3656
              <span style="font-size:12px;color:rgba(195,195,195)">人</span>
            </span>
          </div>
        </div>

        <div class="item_all">
          <div class="item_all_img">
            <img src="./../../../static/img/icon/2.png" alt />
          </div>
          <div class="item_all_qty">
            <div class="item_all_qty_word">健康人数</div>
            <span>
              3656
              <span style="font-size:12px;color:rgb(195,195,195)">人</span>
            </span>
          </div>
        </div>
        <div class="item_all">
          <div class="item_all_img">
            <img src="./../../../static/img/icon/3.png" alt />
          </div>
          <div class="item_all_qty">
            <div class="item_all_qty_word">亚健康人数</div>
            <span>
              3656
              <span style="font-size:12px;color:rgb(195,195,195)">人</span>
            </span>
          </div>
        </div>
        <div class="item_all">
          <div class="item_all_img">
            <img src="./../../../static/img/icon/d.png" alt />
          </div>
          <div class="item_all_qty">
            <div class="item_all_qty_word">患病人数</div>
            <span>
              3656
              <span style="font-size:12px;color:rgb(195,195,195)">人</span>
            </span>
          </div>
        </div>
      </div>
    </div>

    <div class="item_text u-f-column u-f-ac">
                <div class="item_comme1 u-f-ac">
                    <img class="item_icon" src="./../../../static/img/icon/5.png" />
                    <div class="item_title">健康咨询</div>
                 </div>

                  <!--今日报警-->
                  <div class="item_comme2 u-f-ac">
                    <img class="item_icon" src="./../../../static/img/icon/5.png" />
                    <div class="item_title">报警消息</div>
                  </div>

                  <div class="item_comme3 u-f-ac">
                  <img class="item_icon" src="./../../../static/img/icon/5.png" />
                  <div class="item_title">人员导入</div>
                </div>
    </div>
    <div class="item_index2">
       <!--健康资讯-->
      <div class="item u-f-column u-f-ac">
         <div class="item_comter">
          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="置顶消息" name="first"></el-tab-pane>
            <el-tab-pane label="健康知识" name="second"></el-tab-pane>
          </el-tabs>

          <div class="item_comter_list" v-for="(item,index ) in 18" :key="index">
            <div class="item_comter_title">【公告】xxxxxx，xxxxxxxx，xxxxx【公告】xxxxxx，xxxxxxxx，</div>
          </div>

          <div class="more">更多</div>
        </div>

        
      </div>
      <!--报警消息-->
      <div class="item u-f-column u-f-ac">
        <!--概况预览-->
        <div class="item_center u-f-ac">
          <div class="u-f1 u-f-column u-f-ac">
            <div class="item_center_warnning_img">
              <img src="./../../../static/img/icon/f.png" />
            </div>
            <div>今日报警</div>
            <div class="item_center_zero">0</div>
          </div>

          <div class="item_right u-f-ac u-f-column u-f1">
            <div class="item_center_thought_img">
              <img src="./../../../static/img/icon/g.png" />
            </div>
            <div>概况预览</div>
            <div class="item_center_zero">0</div>
          </div>
        </div>
      </div>
     <!--人员导入模块-->
      <div class="item u-f-column u-f-ac">
         <div class="u-f-ac">
          <div class="item_left_img">
            <img src="./../../../static/img/icon/e.png" />
          </div>

          <div class="item_info">用户信息导入</div>
        </div>
      </div>
    </div>
      <div class="item_text u-f-column u-f-ac">
                 <div class="item_comme1 u-f-ac">
                  <img class="item_icon" src="./../../../static/img/icon/5.png" />
                  <div class="item_title">医生入住审核</div>
                </div>

                 <div class="item_comme2 u-f-ac">
                  <img class="item_icon" src="./../../../static/img/icon/5.png" />
                  <div class="item_title">预警区间审核</div>
                </div>

                <div class="item_comme3 u-f-ac">
                  <img class="item_icon" src="./../../../static/img/icon/5.png" />
                  <div class="item_title">数据统计</div>
                </div>

    </div>
    <div class="item_index3">
       <!--医生入驻审核-->
      <div class="item u-f-column u-f-ac u-f1">
        <div class="doctor_block_right u-f-ac">
          <div class="doctor_block_right_first">
            <div class="doctor_block_right_img">
              <img src="./../../../static/img/icon/a1.png" />
            </div>
            <div>今日入驻</div>
            <div class="item_center_zero">0</div>
          </div>

          <div class="doctor_block_right_seconde">
            <div class="doctor_block_right_img2">
              <img src="./../../../static/img/icon/g.png" />
            </div>
            <div>入驻医生概览</div>
            <div class="item_center_zero">0</div>
          </div>
        </div>
      </div>
       <!--预警区间审核-->
      <div class="item u-f-column u-f-ac u-f1">
        
        <div class="doctor_block_center u-f-ac">
          <div class="doctor_block_center_first">
            <div class="doctor_block_center_img">
              <img src="./../../../static/img/icon/a2.png" />
            </div>
            <p>入驻医生概览</p>
            <div class="item_center_zero">0</div>
          </div>

          <div class="doctor_block_center_seconde">
            <div class="doctor_block_right_img2">
              <img src="./../../../static/img/icon/g.png" />
            </div>
            <p>预警区概览</p>
            <div class="item_center_zero">0</div>
          </div>
        </div>
      </div>
       <!--数据统计-->
      <div class="item u-f-column u-f-ac u-f1">
       
        <div class="doctor_block_left">
          <el-row>
            <el-col span="4">
              <p class="blod">高血脂</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="50" status="warning"></el-progress>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="4">
              <p class="blod">高血脂</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="70" status="exception"></el-progress>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="4">
              <p class="blod">高血压</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="30"></el-progress>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="4">
              <p class="blod">高血压</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="90" status="exception"></el-progress>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="4">
              <p class="blod">糖尿病</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="30"></el-progress>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="4">
              <p class="blod">心脏病</p>
            </el-col>
            <el-col span="20">
              <el-progress :percentage="50" status="warning"></el-progress>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    
  </div>
</template>

<script>
import {
  GetMemberDoctorList,
  MemberHealthAdd,
  GetMemberHealthList,
  GetMemberIndex,
  GetMemberHealthInfo_ByWarnId
} from "@/api/oamanagement/workbench";
export default {
  data() {
    return {
      Is_Show_assess: false,
      Is_Show_doctor: false,
      Is_Show_MyAssessInfo: false,
      doctorList: [],
      doctor_InputValue: "",
      list_index: "-1",
      tableData_AssessInfo: [],
      memberIndexInfo_total: "",
      memberIndexInfo_totalWarn: [],
      memberIndexInfo_totalChart: "",
      activeName: "second",
      member_form: {
        ID: 0,
        WarnMemberId: "",
        HealthMemberDoctorId: "",
        HealthWarnId: "",
        HealthLevel: "",
        textarea_assess: "",
        memberInfo: "",
        memberName: "",
        blood_price: "",
        heart_price: "",
        doctor_SearchInput: "",
        memberInform: ""
      }
    };
  },
  mounted() {
    this.GetMemberIndex();

    console.log("用户信息---------------" + localStorage.getItem("memberInfo"));
    console.log("用户id----------------" + localStorage.getItem("memberID"));
  },
  methods: {
    GetMemberIndex() {
      let t_data = this;
      let param = {
        memberId: ""
      };
      GetMemberIndex(param).then(res => {
        if (res.status) {
          t_data.memberIndexInfo_total = res.info.total;
          t_data.memberIndexInfo_totalWarn = res.info.totalWarn;
          t_data.memberIndexInfo_totalChart = res.info.totalChart;
          t_data.getData_HeightEcharts(res.info.totalChart);
          t_data.data_earlyEcharts(res.info.totalChartPre);
          t_data.data_warnInfo_Echarts(res.info.totalWarnChart);
        }
      });
    },

    getEarlyWarning(id) {
      let t_data = this;
      let param = {
        id: id
      };
      GetMemberHealthInfo_ByWarnId(param).then(res => {
        t_data.Is_Show_assess = true;
        t_data.member_form.WarnMemberId = res.info.healthMemberId;
        t_data.member_form.HealthMemberDoctorId = res.info.healthMemberDoctorId;
        t_data.member_form.memberName = res.info.HealthMemberName;
        t_data.member_form.doctor_SearchInput = res.info.HealthMemberDoctorName;
        t_data.member_form.HealthWarnId = res.info.healthWarnId;
        t_data.member_form.memberInform = res.info.healthIntro;
      });
    },

    GetMemberDoctorList(val) {
      let t_data = this;
      if (val == undefined) {
        val = "";
      }
      let param = {
        memberName: val
      };
      GetMemberDoctorList(param).then(res => {
        t_data.doctorList = res.info.list;
      });
    }, //保存评估信息
    save_assess() {
      let t_data = this;
      if (t_data.member_form.HealthMemberDoctorId == "") {
        this.$message.error("请选择医生");
        return;
      }
      if (t_data.member_form.HealthLevel == "") {
        this.$message.error("请选择评估健康状态");
        return;
      }
      if (t_data.member_form.textarea_assess == "") {
        this.$message.error("请填写评估内容");
        return;
      }
      let param = t_data.member_form;
      console.log("params---------------" + param);
      MemberHealthAdd(param).then(res => {
        if (res.status) {
          this.$notify({
            title: "温馨提示",
            message: "评估成功",
            type: "success"
          });
        }

        t_data.Is_Show_assess = false;
        t_data.member_form.HealthLevel = "";
        t_data.member_form.textarea_assess = "";
        t_data.GetMemberIndex();
      });
    },

    //个人评估记录
    GetMemberHealthList() {
      let t_data = this;
      let param = {
        memberName: t_data.member_form.memberName
      };
      t_data.Is_Show_MyAssessInfo = true;
      GetMemberHealthList(param).then(res => {
        t_data.tableData_AssessInfo = res.info.list;
      });
    },

    getDocto_item(index, id, name) {
      this.list_index = index;
      this.member_form.HealthMemberDoctorId = id;
      this.member_form.doctor_SearchInput = name;
    },

    getData_HeightEcharts(data) {
      let t_data = this;
      let echarts = require("echarts");
      let myChart = t_data.$echarts.init(
        document.getElementById("data_HeightEcharts")
      );
      let option = {
        calculable: true,
        tooltip: {
          trigger: "axis"
        },
        legend: {
          textStyle: {
            color: "#fff"
          },
          data: data.name
        },
        grid: {
          top: "15%",
          left: "3%",
          right: "4%",
          bottom: "10%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          axisLine: {
            //这是x轴文字颜色
            lineStyle: {
              width: 1,
              color: "#4164BD"
            }
          },
          data: data.dataX
        },
        yAxis: {
          axisLine: {
            //这是x轴文字颜色
            lineStyle: {
              width: 1,
              color: "#4164BD"
            }
          },
          splitLine: {
            show: false
          },
          type: "value"
        },
        series: [
          {
            name: "健康人数",
            type: "line",
            smooth: true,
            symbolSize: 1,
            itemStyle: {
              normal: { color: "#50CDE1" }
            },
            areaStyle: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(80,205,225,0.5)"
                  },
                  {
                    offset: 0.5,
                    color: "rgba(80,205,225,0.3)"
                  },
                  {
                    offset: 1,
                    color: "rgba(80,205,225,0.1)"
                  }
                ],
                global: false // 缺省为 false
              }
            },
            data: data.dataY1
          },
          {
            name: "亚健康人数",
            type: "line",
            smooth: true,
            symbolSize: 1,
            itemStyle: {
              normal: { color: "#FAD95F" }
            },
            areaStyle: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(250,217,95,0.5)"
                  },
                  {
                    offset: 0.5,
                    color: "rgba(250,217,95,0.3)"
                  },
                  {
                    offset: 1,
                    color: "rgba(250,217,95,0.1)"
                  }
                ],
                global: false // 缺省为 false
              }
            },
            data: data.dataY2
          },
          {
            name: "患病人数",
            type: "line",
            smooth: true,
            symbolSize: 1,
            itemStyle: {
              normal: { color: "#FF7070" }
            },
            areaStyle: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(255,112,112,0.5)"
                  },
                  {
                    offset: 0.5,
                    color: "rgba(255,112,112,0.3)"
                  },
                  {
                    offset: 1,
                    color: "rgba(255,112,112,0.1)"
                  }
                ],
                global: false // 缺省为 false
              }
            },
            data: data.dataY3
          }
        ]
      };
      myChart.setOption(option);
    },
    data_earlyEcharts(data) {
      let t_data = this;
      let echarts = require("echarts");
      let myChart = t_data.$echarts.init(
        document.getElementById("data_earlyEcharts")
      );
      let option = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
          x: "center",
          y: "bottom",
          data: data.name,
          textStyle: {
            color: "#fff"
          }
        },
        graphic: [
          {
            type: "text",
            left: "center",
            top: "45%",
            style: {
              text: "百分比",
              textAlign: "center",
              fill: "#fff",
              width: 30,
              height: 30,
              fontSize: 18
            }
          }
        ],
        color: ["#39ac57", "#37d3b2", "#ef9e1d"],
        series: [
          {
            name: "健康数据统计",
            type: "pie",
            radius: ["50%", "65%"],
            center: ["50%", "45%"],
            data: [
              { value: data.dataY[0], name: data.dataX[0] },
              { value: data.dataY[1], name: data.dataX[1] },
              { value: data.dataY[2], name: data.dataX[2] }
            ]
          }
        ]
      };

      myChart.setOption(option);
    },
    data_warnInfo_Echarts(data) {
      let t_data = this;
      let echarts = require("echarts");
      let myChart = t_data.$echarts.init(
        document.getElementById("data_warnInfo_Echarts")
      );
      let option = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
          x: "center",
          y: "bottom",
          data: data.dataX,
          textStyle: {
            color: "#fff"
          }
        },
        calculable: true,
        color: ["#4F6DCD", "#37d3b2", "#ef9e1d"],
        series: [
          {
            name: "报警处理百分比",
            type: "pie",
            radius: [0, 85],
            center: ["50%", "40%"],
            // roseType: "area",
            data: [
              { value: data.dataY[0], name: "未处理" },
              { value: data.dataY[1], name: "已处理" }
            ]
          }
        ]
      };

      myChart.setOption(option);
    }
  },
  watch: {
    doctor_InputValue(val) {
      this.GetMemberDoctorList(val);
    }
  }
};
</script>


<style  scoped lang="scss">
.container {
  background-color: rgb(245, 245, 245);
  padding: 10px;
  color: #fff;
  margin: auto;

  .item_center_zero {
    font-size: 30px;
    color: rgb(212, 157, 101);
  }

  .item_index1 {
   // margin: auto 9rem;
    h2 {
      color: black;
      font-size: 16px;
    }
    .item_block {
      display: flex;
      align-items: center;
    }
    .item_block > span {
      font-size: 20px;
      color: black;
      padding-left: 15px;
    }
    .item_title {
      display: flex;
      height: 11rem;
      color: black;
      .item_all {
        flex: 1;
        display: flex;
        background-color: #fff;
        margin: auto;

        padding: 1.5rem 1rem;
        font-size: 2.5rem;

        .item_all_img {
          padding: 1rem 1rem;
          img {
            width: 100%;
            height: 100%;
          }
        }
        .item_all_qty_word {
          font-size: 1rem;
        }
        .item_block_first {
          margin-left: 400px;
        }
        .item_block_seconde {
          margin-left: 800px;
        }
        .item_all_qty {
          flex: 1;
          padding: 30px 0px;

          height: 30px;
          span {
            font-size: 2rem;
            color: black;
          }
        }
      }
    }
  }
  .item_text{
      display: flex;
      flex-direction: row;
      justify-content: space-between;
     .item_comme1{
     
      color: black;
     }
   .item_comme2{
     margin-left:9rem;
     color: black;
    }
    .item_comme3{
     margin-right:14rem;
     color: black;
    }
  }
  .item_index2 {
    //margin: 10px 9rem;
    display: flex;
    justify-content: space-between;
    .item {
      color: #333;
      height: 18rem;
      width: 100%;
      padding: 1rem;
      align-items: flex-start;
      background-color: #fff;
      min-width: 300px;
    
    }

    & > :nth-child(1) {
      flex: 1;
      

      .item_comter {
        overflow: hidden;
        overflow-y: scroll;
        margin: 0 4rem;
        .item_comter_list {
          padding: 0.5rem;
        }
      }
     
      .more {
        color: rgb(250, 218, 193);
      }
    }

    & > :nth-child(2) {
      flex: 0.7;
      margin:0 1.5rem;

      .item_icon {
        margin-left: 2rem;
      }
      .item_center {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
      }
    }

    & > :nth-child(3) {
      flex: 0.5;
      height: 10rem;
     
      .item_left_img {
        margin-left: 1rem;
        margin-top: 1rem;
      }
      .item_info{
        margin-top: 1.5rem;
      }
    }
  }

  .item_index3 {
    display: flex;
    margin: 10px 0;
    justify-content: space-between;
    .item {
      color: #333;
      height: 18rem;
      width: 100%;
      padding: 1rem;
      align-items: flex-start;
      background-color: #fff;
      min-width: 300px;
    }

    & > :nth-child(1) {
     
      .item_comter {
        flex: 1;
      }

      .doctor_block_right {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
      }
      .doctor_block_right_first {
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        flex: 1;
      }
      .doctor_block_right_seconde {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
    }

    & > :nth-child(2) {
      flex: 0.7;
      margin: 0 1.5rem;
      .item_center {
        width: 100%;
      }
      .doctor_block_center {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
      }
      .doctor_block_center_first {
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        flex: 1;
      }
      .doctor_block_center_seconde {
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        flex: 1;
      }
    }

    & > :nth-child(3) {
      flex: 0.5;
      background: #fff;
      overflow: hidden;
      overflow-y: scroll;
      .doctor_block_left {
        width: 100%;
      }
      .doctor_block {
        display: flex;
        align-items: center;
      }
      .el-row {
        margin: 2rem 0;
      }
      p {
        font-size: 12px;
      }
    }
  }

  .item_comme {
    display: flex;
    justify-content: space-between;
    .item_icon {
      width: 1rem;
      height: 1.8rem;
      vertical-align: middle;
    }
    .item_title {
      font-size: 1rem;
      height: 1.8rem;
      line-height: 2rem;
      color: #333;
      padding-left: 0.5rem;
    }
  }
}
</style>