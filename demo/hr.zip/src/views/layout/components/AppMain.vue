<template>
  <div style="height: 100%;">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {}
}
</script>

<style scoped>
</style>
